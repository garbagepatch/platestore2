#define FFI_LIB "Kernel32.dll"
typedef unsigned long DWORD;
DWORD GetLastError(void);
