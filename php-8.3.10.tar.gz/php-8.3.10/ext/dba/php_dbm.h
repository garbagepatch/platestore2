#ifndef PHP_DBM_H
#define PHP_DBM_H

#ifdef DBA_DBM

#include "php_dba.h"

DBA_FUNCS(dbm);

#endif

#endif
